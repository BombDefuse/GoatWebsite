import { env } from './env';

type BanInfo = {
  SteamId: string;
  CommunityBanned: boolean;
  VACBanned: boolean;
  NumberOfVACBans: number;
  DaysSinceLastBan: number;
  NumberOfGameBans: number;
  EconomyBan: string;
};

type SummaryInfo = {
  steamid: string;
  personaname: string;
  profileurl: string;
  avatarfull: string;
};

export function parseSteamInput(raw: string) {
  const input = raw.trim();
  if (!input) {
    throw new Error('Please enter a Steam profile URL, custom URL, or SteamID64.');
  }

  if (/^\d{17}$/.test(input)) {
    return { type: 'steamid64' as const, value: input };
  }

  let url: URL;
  try {
    url = input.startsWith('http://') || input.startsWith('https://') ? new URL(input) : new URL(`https://${input}`);
  } catch {
    throw new Error('That does not look like a valid Steam profile URL or SteamID64.');
  }

  if (!url.hostname.includes('steamcommunity.com')) {
    throw new Error('Only steamcommunity.com profile URLs are supported.');
  }

  const parts = url.pathname.split('/').filter(Boolean);
  if (parts.length < 2) {
    throw new Error('Use a full Steam profile URL like /id/name or /profiles/steamid64.');
  }

  if (parts[0] === 'profiles' && /^\d{17}$/.test(parts[1])) {
    return { type: 'steamid64' as const, value: parts[1] };
  }

  if (parts[0] === 'id' && parts[1]) {
    return { type: 'vanity' as const, value: parts[1] };
  }

  throw new Error('Unsupported Steam URL format. Use /id/<name> or /profiles/<steamid64>.');
}

async function steamFetch<T>(url: string): Promise<T> {
  const response = await fetch(url, { cache: 'no-store' });
  if (!response.ok) {
    throw new Error(`Steam API request failed with ${response.status}.`);
  }
  return response.json() as Promise<T>;
}

export async function resolveSteamId(input: string) {
  const parsed = parseSteamInput(input);
  if (parsed.type === 'steamid64') return parsed.value;

  const url = new URL('https://api.steampowered.com/ISteamUser/ResolveVanityURL/v1/');
  url.searchParams.set('key', env.steamApiKey);
  url.searchParams.set('vanityurl', parsed.value);

  const data = await steamFetch<{ response: { success: number; steamid?: string; message?: string } }>(url.toString());
  if (data.response.success !== 1 || !data.response.steamid) {
    throw new Error(data.response.message || 'Steam could not resolve that custom profile URL.');
  }

  return data.response.steamid;
}

export async function getPlayerBans(steamid64: string) {
  const url = new URL('https://api.steampowered.com/ISteamUser/GetPlayerBans/v1/');
  url.searchParams.set('key', env.steamApiKey);
  url.searchParams.set('steamids', steamid64);

  const data = await steamFetch<{ players: BanInfo[] }>(url.toString());
  const player = data.players[0];
  if (!player) throw new Error('Steam did not return ban information for that profile.');
  return player;
}

export async function getPlayerSummary(steamid64: string) {
  const url = new URL('https://api.steampowered.com/ISteamUser/GetPlayerSummaries/v2/');
  url.searchParams.set('key', env.steamApiKey);
  url.searchParams.set('steamids', steamid64);

  const data = await steamFetch<{ response: { players: SummaryInfo[] } }>(url.toString());
  const player = data.response.players[0];
  if (!player) throw new Error('Steam did not return profile information for that account.');
  return player;
}

export async function fetchSteamProfile(input: string) {
  const steamid64 = await resolveSteamId(input);
  const [ban, summary] = await Promise.all([getPlayerBans(steamid64), getPlayerSummary(steamid64)]);

  return {
    input_url: input,
    steamid64,
    display_name: summary.personaname,
    profile_url: summary.profileurl,
    avatar_url: summary.avatarfull,
    vac_banned: ban.VACBanned,
    number_of_vac_bans: ban.NumberOfVACBans,
    number_of_game_bans: ban.NumberOfGameBans,
    days_since_last_ban: ban.DaysSinceLastBan,
    community_banned: ban.CommunityBanned,
    economy_ban: ban.EconomyBan
  };
}
