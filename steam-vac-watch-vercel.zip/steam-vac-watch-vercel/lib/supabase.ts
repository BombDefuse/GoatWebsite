import { createClient } from '@supabase/supabase-js';
import { env } from './env';

export type ProfileRow = {
  id: number;
  input_url: string;
  steamid64: string;
  display_name: string | null;
  profile_url: string | null;
  avatar_url: string | null;
  vac_banned: boolean;
  number_of_vac_bans: number;
  number_of_game_bans: number;
  days_since_last_ban: number;
  community_banned: boolean;
  economy_ban: string;
  tracked_since: string;
  last_checked_at: string | null;
  first_seen_vac_ban_at: string | null;
  created_at: string;
};

export function getSupabaseAdmin() {
  return createClient(env.supabaseUrl, env.supabaseServiceRoleKey, {
    auth: {
      persistSession: false,
      autoRefreshToken: false
    }
  });
}
