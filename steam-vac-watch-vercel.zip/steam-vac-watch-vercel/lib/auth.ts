import crypto from 'crypto';
import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import { env } from './env';

const COOKIE_NAME = 'steam_vac_watch_session';

function sign(value: string) {
  return crypto.createHmac('sha256', env.sessionSecret).update(value).digest('hex');
}

function makeToken(password: string) {
  return `${password}.${sign(password)}`;
}

export function isValidToken(token: string | undefined) {
  if (!token) return false;
  const [password, signature] = token.split('.');
  if (!password || !signature) return false;
  const expected = sign(password);
  return crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected)) && password === env.appPassword;
}

export async function requireAuth() {
  const token = cookies().get(COOKIE_NAME)?.value;
  if (!isValidToken(token)) {
    redirect('/login');
  }
}

export function createSessionCookie() {
  return {
    name: COOKIE_NAME,
    value: makeToken(env.appPassword),
    httpOnly: true,
    sameSite: 'lax' as const,
    secure: true,
    path: '/',
    maxAge: 60 * 60 * 24 * 30
  };
}

export function clearSessionCookie() {
  return {
    name: COOKIE_NAME,
    value: '',
    httpOnly: true,
    sameSite: 'lax' as const,
    secure: true,
    path: '/',
    maxAge: 0
  };
}
