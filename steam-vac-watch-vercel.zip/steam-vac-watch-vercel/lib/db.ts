import { getSupabaseAdmin, ProfileRow } from './supabase';
import { fetchSteamProfile } from './steam';

export async function listProfiles() {
  const supabase = getSupabaseAdmin();
  const { data, error } = await supabase
    .from('tracked_profiles')
    .select('*')
    .order('created_at', { ascending: false });

  if (error) throw new Error(error.message);
  return (data ?? []) as ProfileRow[];
}

export async function addProfile(inputUrl: string) {
  const supabase = getSupabaseAdmin();
  const profile = await fetchSteamProfile(inputUrl);

  const { data: existing, error: existingError } = await supabase
    .from('tracked_profiles')
    .select('*')
    .eq('steamid64', profile.steamid64)
    .maybeSingle();

  if (existingError) throw new Error(existingError.message);
  if (existing) {
    return { alreadyExists: true, profile: existing as ProfileRow };
  }

  const payload = {
    ...profile,
    last_checked_at: new Date().toISOString(),
    first_seen_vac_ban_at: profile.vac_banned ? new Date().toISOString() : null
  };

  const { data, error } = await supabase
    .from('tracked_profiles')
    .insert(payload)
    .select('*')
    .single();

  if (error) throw new Error(error.message);
  return { alreadyExists: false, profile: data as ProfileRow };
}

export async function refreshProfiles() {
  const supabase = getSupabaseAdmin();
  const profiles = await listProfiles();

  for (const row of profiles) {
    const latest = await fetchSteamProfile(row.profile_url || row.input_url);
    const becameVacBanned = !row.vac_banned && latest.vac_banned;

    const { error } = await supabase
      .from('tracked_profiles')
      .update({
        display_name: latest.display_name,
        profile_url: latest.profile_url,
        avatar_url: latest.avatar_url,
        vac_banned: latest.vac_banned,
        number_of_vac_bans: latest.number_of_vac_bans,
        number_of_game_bans: latest.number_of_game_bans,
        days_since_last_ban: latest.days_since_last_ban,
        community_banned: latest.community_banned,
        economy_ban: latest.economy_ban,
        last_checked_at: new Date().toISOString(),
        first_seen_vac_ban_at: becameVacBanned ? new Date().toISOString() : row.first_seen_vac_ban_at
      })
      .eq('id', row.id);

    if (error) throw new Error(error.message);
  }
}

export async function deleteProfile(id: string) {
  const supabase = getSupabaseAdmin();
  const { error } = await supabase.from('tracked_profiles').delete().eq('id', id);
  if (error) throw new Error(error.message);
}
