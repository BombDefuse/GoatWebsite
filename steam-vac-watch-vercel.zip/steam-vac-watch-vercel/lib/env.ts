function requireEnv(name: string): string {
  const value = process.env[name];
  if (!value) {
    throw new Error(`Missing environment variable: ${name}`);
  }
  return value;
}

export const env = {
  appPassword: requireEnv('APP_PASSWORD'),
  sessionSecret: requireEnv('SESSION_SECRET'),
  steamApiKey: requireEnv('STEAM_API_KEY'),
  supabaseUrl: requireEnv('SUPABASE_URL'),
  supabaseServiceRoleKey: requireEnv('SUPABASE_SERVICE_ROLE_KEY'),
  cronSecret: requireEnv('CRON_SECRET')
};
