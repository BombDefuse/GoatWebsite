import './globals.css';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Steam VAC Watch',
  description: 'Track Steam profiles and see when a tracked account receives a VAC ban.'
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
