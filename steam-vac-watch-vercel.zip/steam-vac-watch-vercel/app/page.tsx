import { requireAuth } from '../lib/auth';
import { listProfiles } from '../lib/db';

function fmtDate(value: string | null) {
  if (!value) return '—';
  return new Date(value).toLocaleString();
}

export default async function HomePage({ searchParams }: { searchParams?: { ok?: string; error?: string } }) {
  await requireAuth();
  const profiles = await listProfiles();
  const vacCount = profiles.filter((p) => p.vac_banned).length;
  const newlyFlagged = profiles.filter((p) => p.first_seen_vac_ban_at).length;

  return (
    <main>
      <div className="stack" style={{ justifyContent: 'space-between', marginBottom: 24 }}>
        <div>
          <h1 style={{ margin: 0 }}>Steam VAC Watch</h1>
          <p className="muted">Track Steam profiles and see which tracked accounts received a VAC ban.</p>
        </div>
        <form action="/api/logout" method="post">
          <button className="secondary" type="submit">Log out</button>
        </form>
      </div>

      {searchParams?.ok ? <p className="badge good" style={{ borderRadius: 12 }}>{decodeURIComponent(searchParams.ok)}</p> : null}
      {searchParams?.error ? <p className="badge bad" style={{ borderRadius: 12 }}>{decodeURIComponent(searchParams.error)}</p> : null}

      <section className="grid grid-3" style={{ marginTop: 20 }}>
        <div className="card">
          <div className="muted">Tracked profiles</div>
          <div style={{ fontSize: 32, fontWeight: 800, marginTop: 8 }}>{profiles.length}</div>
        </div>
        <div className="card">
          <div className="muted">Currently VAC banned</div>
          <div style={{ fontSize: 32, fontWeight: 800, marginTop: 8 }}>{vacCount}</div>
        </div>
        <div className="card">
          <div className="muted">Seen VAC bans since tracking</div>
          <div style={{ fontSize: 32, fontWeight: 800, marginTop: 8 }}>{newlyFlagged}</div>
        </div>
      </section>

      <section className="card" style={{ marginTop: 20 }}>
        <h2 style={{ marginTop: 0 }}>Add a profile</h2>
        <p className="muted">Paste a Steam profile URL, custom /id/ URL, or a 17-digit SteamID64.</p>
        <form action="/api/add" method="post" className="stack">
          <input name="inputUrl" placeholder="https://steamcommunity.com/id/example" required />
          <button type="submit">Add profile</button>
        </form>
      </section>

      <section className="card" style={{ marginTop: 20 }}>
        <div className="stack" style={{ justifyContent: 'space-between' }}>
          <div>
            <h2 style={{ margin: 0 }}>Tracked profiles</h2>
            <p className="muted">Manual refresh checks all rows immediately. The Vercel cron is configured for one daily refresh.</p>
          </div>
          <form action="/api/refresh" method="post">
            <button type="submit">Refresh now</button>
          </form>
        </div>

        <div className="table-wrap" style={{ marginTop: 16 }}>
          <table>
            <thead>
              <tr>
                <th>Profile</th>
                <th>Status</th>
                <th>Ban details</th>
                <th>Last checked</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {profiles.length === 0 ? (
                <tr>
                  <td colSpan={5} className="muted">No profiles tracked yet.</td>
                </tr>
              ) : profiles.map((profile) => (
                <tr key={profile.id}>
                  <td>
                    <div className="stack">
                      {profile.avatar_url ? <img className="avatar" src={profile.avatar_url} alt="avatar" /> : null}
                      <div>
                        <div style={{ fontWeight: 700 }}>{profile.display_name || 'Unknown profile'}</div>
                        <div className="muted" style={{ fontSize: 14 }}>{profile.steamid64}</div>
                        {profile.profile_url ? <a href={profile.profile_url} target="_blank">Open Steam profile</a> : null}
                      </div>
                    </div>
                  </td>
                  <td>
                    {profile.vac_banned ? <span className="badge bad">VAC banned</span> : <span className="badge good">No VAC ban</span>}
                    {profile.first_seen_vac_ban_at ? <div style={{ marginTop: 8 }}><span className="badge warn">Seen while tracked</span></div> : null}
                  </td>
                  <td>
                    <div>VAC bans: {profile.number_of_vac_bans}</div>
                    <div>Game bans: {profile.number_of_game_bans}</div>
                    <div>Days since last ban: {profile.days_since_last_ban}</div>
                    <div>Economy ban: {profile.economy_ban}</div>
                  </td>
                  <td>
                    <div>{fmtDate(profile.last_checked_at)}</div>
                    <div className="muted" style={{ fontSize: 14 }}>Tracked since {fmtDate(profile.tracked_since)}</div>
                    {profile.first_seen_vac_ban_at ? <div className="muted" style={{ fontSize: 14 }}>First seen VAC banned {fmtDate(profile.first_seen_vac_ban_at)}</div> : null}
                  </td>
                  <td>
                    <form action="/api/delete" method="post">
                      <input type="hidden" name="id" value={String(profile.id)} />
                      <button className="danger" type="submit">Remove</button>
                    </form>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </main>
  );
}
