import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import { isValidToken } from '../../lib/auth';

export default function LoginPage({ searchParams }: { searchParams?: { error?: string } }) {
  const token = cookies().get('steam_vac_watch_session')?.value;
  if (isValidToken(token)) {
    redirect('/');
  }

  return (
    <main style={{ maxWidth: 420, minHeight: '100vh', display: 'grid', placeItems: 'center' }}>
      <div className="card" style={{ width: '100%' }}>
        <h1 style={{ marginTop: 0 }}>Steam VAC Watch</h1>
        <p className="muted">Private login for your group.</p>
        {searchParams?.error ? (
          <p className="badge bad" style={{ borderRadius: 12 }}>{decodeURIComponent(searchParams.error)}</p>
        ) : null}
        <form action="/api/login" method="post" className="grid" style={{ marginTop: 16 }}>
          <label>
            <div style={{ marginBottom: 8 }}>Password</div>
            <input type="password" name="password" required />
          </label>
          <button type="submit">Sign in</button>
        </form>
      </div>
    </main>
  );
}
