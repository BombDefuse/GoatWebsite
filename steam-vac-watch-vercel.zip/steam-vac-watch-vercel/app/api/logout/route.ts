import { cookies } from 'next/headers';
import { NextRequest, NextResponse } from 'next/server';
import { clearSessionCookie } from '../../../lib/auth';

export async function POST(request: NextRequest) {
  cookies().set(clearSessionCookie());
  return NextResponse.redirect(new URL('/login', request.url));
}
