import { NextRequest, NextResponse } from 'next/server';
import { deleteProfile } from '../../../lib/db';

export async function POST(request: NextRequest) {
  const form = await request.formData();
  const id = String(form.get('id') || '');

  try {
    await deleteProfile(id);
    return NextResponse.redirect(new URL('/?ok=Profile%20removed.', request.url));
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Could not remove that profile.';
    return NextResponse.redirect(new URL(`/?error=${encodeURIComponent(message)}`, request.url));
  }
}
