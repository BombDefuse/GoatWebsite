import { NextRequest, NextResponse } from 'next/server';
import { addProfile } from '../../../lib/db';

export async function POST(request: NextRequest) {
  const form = await request.formData();
  const inputUrl = String(form.get('inputUrl') || '');

  try {
    const result = await addProfile(inputUrl);
    const message = result.alreadyExists ? 'That profile is already being tracked.' : 'Profile added.';
    return NextResponse.redirect(new URL(`/?ok=${encodeURIComponent(message)}`, request.url));
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Could not add that profile.';
    return NextResponse.redirect(new URL(`/?error=${encodeURIComponent(message)}`, request.url));
  }
}
