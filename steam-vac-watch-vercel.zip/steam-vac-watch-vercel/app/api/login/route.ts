import { cookies } from 'next/headers';
import { NextRequest, NextResponse } from 'next/server';
import { createSessionCookie } from '../../../lib/auth';
import { env } from '../../../lib/env';

export async function POST(request: NextRequest) {
  const form = await request.formData();
  const password = String(form.get('password') || '');

  if (password !== env.appPassword) {
    return NextResponse.redirect(new URL('/login?error=Wrong%20password', request.url));
  }

  cookies().set(createSessionCookie());
  return NextResponse.redirect(new URL('/', request.url));
}
