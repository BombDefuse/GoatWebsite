import { NextRequest, NextResponse } from 'next/server';
import { refreshProfiles } from '../../../lib/db';
import { env } from '../../../lib/env';

async function runRefresh() {
  await refreshProfiles();
  return NextResponse.json({ ok: true });
}

export async function GET(request: NextRequest) {
  const secret = request.nextUrl.searchParams.get('cron_secret');
  if (secret !== env.cronSecret) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  return runRefresh();
}

export async function POST(request: NextRequest) {
  try {
    await refreshProfiles();
    return NextResponse.redirect(new URL('/?ok=Refresh%20completed.', request.url));
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Refresh failed.';
    return NextResponse.redirect(new URL(`/?error=${encodeURIComponent(message)}`, request.url));
  }
}
