create table if not exists public.tracked_profiles (
  id bigint generated always as identity primary key,
  input_url text not null,
  steamid64 text not null unique,
  display_name text,
  profile_url text,
  avatar_url text,
  vac_banned boolean not null default false,
  number_of_vac_bans integer not null default 0,
  number_of_game_bans integer not null default 0,
  days_since_last_ban integer not null default 0,
  community_banned boolean not null default false,
  economy_ban text not null default 'none',
  tracked_since timestamptz not null default now(),
  last_checked_at timestamptz,
  first_seen_vac_ban_at timestamptz,
  created_at timestamptz not null default now()
);

alter table public.tracked_profiles enable row level security;

create policy "deny_all_client_access"
  on public.tracked_profiles
  for all
  using (false)
  with check (false);
